public enum cardStatus {
    TODO,
    INPROGRESS,
    TOBEREVISED,
    DONE
}
